const Validation = yup => ({
  roles: yup.string()
})

export default Validation