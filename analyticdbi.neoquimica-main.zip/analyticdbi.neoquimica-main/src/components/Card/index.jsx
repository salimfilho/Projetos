import { Card } from './styled'

const Component = props =>
    <Card>
        {props.children}
    </Card>

export default Component