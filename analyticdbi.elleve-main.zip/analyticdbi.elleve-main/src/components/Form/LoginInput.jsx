import { LoginInput } from './styled'

const Component = ({ type, name, label, readOnly, variant, formik }) => {
  return (
    <LoginInput>
      <div>
        {formik.touched[name] && formik.errors[name] ?
          formik.errors[name] :
          null}
      </div>
      <input
        type={!type ? 'text' : type}
        id={name}
        name={name}
        readOnly={readOnly}
        className={variant}
        value={formik.values[name]}
        onChange={formik.handleChange}
      />
      <span>{label}</span>
    </LoginInput >
  )
}

export default Component
