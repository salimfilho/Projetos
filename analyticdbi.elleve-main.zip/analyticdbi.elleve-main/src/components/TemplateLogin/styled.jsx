import styled from 'styled-components'

export const Login = styled.section`
  display: flex;
  height: 100vh;
`
export const Image = styled.div`
  background-color: var(--color-sidebar);
  flex: 3;
  padding-top: 70px;
  & div {
    width: 100%;
    height: calc(100vh - 70px);
    background-image: url('/login.jpg');
    background-repeat: no-repeat;
    background-position: right top;
    background-size: auto 100%;
  }
  @media (max-width: 1440px) {
    flex: 2;
    & div {
      background-position: left top;
    }
  }
  @media (max-width: 960px) {
    display: none;
  }
`
export const Form = styled.div`
  flex: 2;
  padding: 25px;
  background-color: var(--color-sidebar);
`
export const Logo = styled.div`
  padding: 25px 25px 100px 25px;
  & img {
    height: 40px;
  }
`