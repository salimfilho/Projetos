import { Login, Image, Form, Logo } from './styled'

const Base = ChildrenComponent => {

  const ComponentBase = props => {
    return (
      <Login>
        <Form>
          <Logo>
            <img src="/logo.png" alt="elleve" />
          </Logo>
          <ChildrenComponent {...props} />
        </Form>
        <Image>
          <div></div>
        </Image>
      </Login>
    )
  }

  return ComponentBase
}

export default Base