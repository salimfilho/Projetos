import { BtnGreen } from './styled'

const Component = props => {
    return (
        <BtnGreen type={props.type}>
            {props.children}
        </BtnGreen>
    )
}

export default Component