import styled from 'styled-components'

export const TopbarMenu = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    color: var(--color-white);
    &:hover {
        cursor: pointer;
        opacity: 0.5;
    }
`
export const Topbar = styled.header`
    height: 120px;
    width: 100%;
    background-color: var(--color-sidebar);
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 1;
    @media (max-width: 1140px) {
        position: fixed;
    }
`
export const TopbarMenuDesktop = styled(TopbarMenu)`
    transition: all ease 0.2s;
    height: inherit;
    & span {
        margin-left: 70px;
        font-size: 35px;
        color: var(--color-white);
        display: flex;
    }
    @media (max-width: 1140px) {
        & {
            display: none;
        }
    }
`
export const TopbarMenuMobile = styled(TopbarMenu)`
    transition: all ease 0.2s;
    &.menu-open {
        margin-left: 240px;
    }
    @media (max-width: 2562px) {
        & {
            display: none;
        }
    }
    @media (max-width: 1140px) {
        & {
            display: flex;
        }
    }
`
export const Logout = styled.button`
    margin: 0 30px;
    padding: 15px 50px;
    border-radius: 30px;
    border: none;
    color: var(--color-black);
    font-size: 18px;
    font-weight: bold;
    background-color: var(--color-green);
    &:hover {
        cursor: pointer;
        opacity: 0.5;
    }
`