import styled from 'styled-components'

export const Td = styled.td`
    display: flex;
    & a {
        margin: 0 5px;
    }
`