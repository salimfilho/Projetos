import { Td } from './styled'

const Component = props => {
    return (
        <Td>
            {props.children}
        </Td>
    )
}

export default Component