import { Spinner } from './styled'

const Component = () =>
    <Spinner></Spinner>

export default Component