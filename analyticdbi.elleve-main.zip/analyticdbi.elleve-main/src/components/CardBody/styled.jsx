import styled from 'styled-components'

export const CardBody = styled.div`
  padding: 30px 15px 15px;
`