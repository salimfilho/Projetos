import { useContext, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Sidebar, Menu, SidebarBrand, User, Name, Email } from './styled'
import {  FaChartArea } from "react-icons/fa"
import MenuItem from 'components/MenuItem'
import { Context } from 'contexts/context'
import { getUser } from 'services/auth'

const Component = () => {

  const { toggle } = useContext(Context)
  const [data, setData] = useState({})

  useEffect(() => {
    (async () => {
      setData(getUser().data)
    })()
  }, [])

  const { file_url, name, email, roles } = data

  return (
    <Sidebar
      className={`
        ${toggle ? 'open' : 'closed'}
        ${toggle ? 'menu-open' : 'menu-closed'}
      `}
    >
      <div>
        <Link to="/dashboard">
          <SidebarBrand className={toggle ? 'open' : 'closed'} >
            <img className="logo" src="/logo.png" alt="elleve" />
            <img className="logo-mini" src="/icone.png" alt="elleve" />
          </SidebarBrand>
        </Link>
        <User to="/profile">
          <img className={`${toggle ? 'open' : 'closed'}`} src={file_url ? file_url : '/user.svg'} alt="analyticdbi" />
          <div className={`${toggle ? 'open' : 'closed'}`}>
            <Name>{name}</Name>
            <Email>{email}</Email>
          </div>
        </User>
        <Menu>
          {roles === 'admin' ? <MenuItem path="/grupos" icon="/report.png" label="Relatórios" /> : <MenuItem path="/relatorios" icon={<FaChartArea />} label="Relatórios" />}
          {roles === 'admin' && <MenuItem path="/usuarios" icon="/user.png" label="Usuários" />}
        </Menu>
      </div>
    </Sidebar>
  )
}

export default Component