import Input from 'components/Form/LoginInput'
import BtnGreen from 'components/Button/BtnGreen'
import Messages from 'components/Messages'
import Spinner from 'components/Spinner'
import { Login, SubTitle, InputBox, BtnBox } from './styled'

const Component = ({ formik, messages }) => {
  return (
    <Login>
      <h1>Esqueci a senha</h1>
      <SubTitle>Informe sua nova senha.</SubTitle>
      <form onSubmit={formik.handleSubmit}>
        <Messages formMessages={messages.messages} alert={messages.alert} />
        <InputBox>
          <Input
            type="password"
            name="password"
            label="Senha"
            formik={formik}
          />
        </InputBox>
        <InputBox>
          <Input
            type="password"
            name="password_confirmation"
            label="Confirmar"
            formik={formik}
          />
        </InputBox>
        <BtnBox>
          <BtnGreen type="submit" disabled={formik.isSubmitting}>
            {formik.isSubmitting ? <Spinner /> : "Enviar"}
          </BtnGreen>
        </BtnBox>
      </form>
    </Login>
  )
}

export default Component