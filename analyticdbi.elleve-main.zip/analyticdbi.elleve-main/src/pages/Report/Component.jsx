import { PowerBIEmbed } from 'powerbi-client-react'
// import TitleBar from 'components/TitleBar'
import Content from 'components/Content'
import './style.css'

const Component = props => {
    // const breadcrumb = [
    //     { path: '/grupos', label: 'Index' },
    //     { path: `/grupos/${props.params.group_id}/relatorios`, label: 'Relatórios' }
    // ]
    return (
        <>
            {/* <TitleBar label="Relatórios" currentPage="Embed" breadcrumb={breadcrumb} /> */}
            <Content>
                <PowerBIEmbed
                    embedConfig={{
                        type: 'report',
                        id: props.data.reportId,
                        embedUrl: props.data.embedUrl,
                        accessToken: props.data.token,
                        tokenType: props.data.type,
                        settings: {
                            panes: {
                                filters: {
                                    visible: false
                                },
                                pageNavigation: {
                                    visible: false
                                }
                            }
                        }
                    }}
                    cssClassName={"report"}
                />
            </Content>
        </>
    )
}

export default Component
