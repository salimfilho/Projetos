const Validation = yup => ({
  user_id: yup.string().required('Campo obrigatório'),
  report_id: yup.string().required('Campo obrigatório'),
  roles: yup.string()
})

export default Validation