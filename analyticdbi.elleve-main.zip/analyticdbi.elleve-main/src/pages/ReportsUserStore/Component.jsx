import TitleBar from 'components/TitleBar'
import Content from 'components/Content'
import Card from 'components/Card'
import CardTitle from 'components/CardTitle'
import Input from 'components/Form/LabelInput'
import Select from 'components/Form/LabelSelect'
import BtnBlue from 'components/Button/BtnBlue'
import Messages from 'components/Messages'
import Spinner from 'components/Spinner'
import Table from 'components/Table'
import CardBody from 'components/CardBody'
import BtnBox from 'components/Button/BtnBox'

const Component = props => {
  const breadcrumb = [
    { path: '/usuarios', label: 'Index' },
    { path: `/usuarios/${props.params.id}/relatorios`, label: 'Relatórios' }
  ]
  return (
    <>
      <TitleBar label="Usuários" currentPage="Cadastrar" breadcrumb={breadcrumb} />
      <Content>
        <Card>
          <CardTitle title="Usuário" />
          <Table>
            <thead>
              <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Permissão</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{props.user.name}</td>
                <td>{props.user.email}</td>
                <td>{props.user.roles}</td>
              </tr>
            </tbody>
          </Table>
        </Card>
        <Card>
          <CardTitle title="Cadastrar"></CardTitle>
          <Content>
            <CardBody>
              <form onSubmit={props.formik.handleSubmit}>
                <Messages formMessages={props.messages.messages} alert={props.messages.alert} />
                <Select name="group" label="Grupos" formik={props.formik}>
                  <option value="">Selecione...</option>
                  {props.groups.map(group => <option key={group.id} value={group.id}>{group.name}</option>)}
                </Select>
                <Select name="report_id" label="Relatórios" formik={props.formik}>
                  <option value="">Selecione...</option>
                  {props.reports.map(report => <option key={report.id} value={report.id}>{report.name}</option>)}
                </Select>
                <Input name="roles" label="Roles" formik={props.formik} />
                <BtnBox>
                  <BtnBlue type="submit" disabled={props.formik.isSubmitting}>
                    {props.formik.isSubmitting ? <Spinner /> : "Enviar"}
                  </BtnBlue>
                </BtnBox>
              </form>
            </CardBody>
          </Content>
        </Card>
      </Content>
    </>
  )
}

export default Component