import { useEffect, useState } from 'react'
import { useHistory, useParams } from 'react-router-dom'
import { useFormik } from 'formik'
import * as Yup from 'yup'
import Validation from './validation'
import { handleStoreReport } from 'services/api/reports'
import { handlePowerBiGroups, handlePowerBiReports } from 'services/api/powerbi'
import { handleUserShow } from 'services/api/users'
import Component from './Component'

const Page = () => {
    const params = useParams()
    const [groups, setGroups] = useState([])
    const [reports, setReports] = useState([])
    const [user, setUser] = useState({})

    useEffect(() => {
        (async () => {
            setGroups(await handlePowerBiGroups())
            setUser(await handleUserShow(params.id))
        })()
    }, [params.id])

    const [messages, setMessages] = useState({ messages: [], alert: '' })
    const history = useHistory()
    const formik = useFormik({
        initialValues: { user_id: params.id, name: '', report_id: '', roles: '', dataset_id: '', group: '' },
        validationSchema: Yup.object(Validation(Yup)),
        onSubmit: () => handleStoreReport(history, formik.values, params.id, setMessages)
    })

    useEffect(() => {
        (async () => {
            if (formik.values.group) {
                setReports(await handlePowerBiReports(formik.values.group))
            }
        })()
    }, [formik.values.group])

    useEffect(() => {
        if (formik.values.report_id) {
            formik.setFieldValue('name', (reports.find(element => element.id === formik.values.report_id)).name)
            formik.setFieldValue('dataset_id', (reports.find(element => element.id === formik.values.report_id)).datasetId)
        }
    }, [formik.values.report_id])

    return <Component
        formik={formik}
        messages={messages}
        params={params}
        groups={groups}
        reports={reports}
        user={user}
    />
}

export default Page