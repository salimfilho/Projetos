import styled from 'styled-components'

export const Login = styled.div`
  padding: 0 25px;
  & h1 {
    font-size: 32px;
    padding: 10px 0;
  }
`
export const SubTitle = styled.p`
  color: var(--color-white);
  font-weight: bold;
  margin-bottom: 25px;
`
export const InputBox = styled.div`
  padding: 10px 0;
`
export const BtnBox = styled.div`
  padding: 40px 0;
  width: 100%;
  & button {
    width: 100%;
  }
`
export const ForgotPassword = styled.div`
  width: 100%;
  display: flex;
  justify-content: flex-end;
  & a {
    text-decoration: none;
    color: var(--color-font);
    font-weight: bold;
  }
`