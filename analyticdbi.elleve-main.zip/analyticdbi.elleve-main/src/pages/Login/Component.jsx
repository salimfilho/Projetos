import { Link } from 'react-router-dom'
import Input from 'components/Form/LoginInput'
import BtnGreen from 'components/Button/BtnGreen'
import Messages from 'components/Messages'
import Spinner from 'components/Spinner'
import { Login, SubTitle, InputBox, BtnBox, ForgotPassword } from './styled'

const Component = ({ formik, messages }) => {
  return (
    <Login>
      <h1>Login</h1>
      <SubTitle>Entre com o seu email e senha.</SubTitle>
      <form onSubmit={formik.handleSubmit}>
        <Messages formMessages={messages.messages} alert={messages.alert} />
        <InputBox>
          <Input
            type="email"
            name="email"
            label="Email*"
            formik={formik}
          />
        </InputBox>
        <InputBox>
          <Input
            type="password"
            name="password"
            label="Senha*"
            formik={formik}
          />
        </InputBox>
        <ForgotPassword>
          <Link to="/esqueci-senha">Esqueceu a senha?</Link>
        </ForgotPassword>
        <BtnBox>
          <BtnGreen type="submit" disabled={formik.isSubmitting}>
            {formik.isSubmitting ? <Spinner /> : "Entrar"}
          </BtnGreen>
        </BtnBox>
      </form>
    </Login>
  )
}

export default Component