import TitleBar from 'components/TitleBar'
import Content from 'components/Content'
import Card from 'components/Card'
import CardTitle from 'components/CardTitle'
import Table from 'components/Table'
import SmLinkBlue from 'components/Button/SmLinkBlue'
import { FaChartArea } from "react-icons/fa"

const Component = props => {
    const breadcrumb = [
        { path: '/grupos', label: 'Index' }
    ]
    return (
        <>
            <TitleBar label="Relatórios" currentPage="Relatórios" breadcrumb={breadcrumb} />
            <Content>
                <Card>
                    <CardTitle title="Relatórios" />
                    <Table>
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th width="50">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            {props.data.map(item =>
                                <tr key={item.id}>
                                    <td>{item.name}</td>
                                    <td>
                                        {
                                            props.user.roles === 'admin' ?
                                                <SmLinkBlue to={`/grupos/${props.params.group_id}/relatorios/${item.id}/datasets/${item.datasetId}`}>
                                                    <FaChartArea />
                                                </SmLinkBlue> :
                                                <SmLinkBlue to={`/grupos/${item.group_id}/relatorios/${item.report_id}/datasets/${item.dataset_id}`}>
                                                    <FaChartArea />
                                                </SmLinkBlue>
                                        }
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </Table>
                </Card>
            </Content>
        </>
    )
}

export default Component