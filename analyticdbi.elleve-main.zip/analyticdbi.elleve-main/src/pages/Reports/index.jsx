import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { handlePowerBiReports } from 'services/api/powerbi'
import { handleReportsByUser } from 'services/api/reports'
import { getUser } from 'services/auth'
import Component from './Component'

const Page = () => {

    const params = useParams()
    const [data, setData] = useState([])
    const [user, setUser] = useState({})

    useEffect(() => {
        new Promise(resolve => resolve(getUser()))
            .then(res => {
                setUser(res.data)
                return res
            })
            .then(async res => {
                if (res.data.roles === 'admin') {
                    setData(await handlePowerBiReports(params.group_id))
                }
                if (res.data.roles === 'user') {
                    // const reports = await handlePowerBiReports(params.group_id)
                    const reportsUser = await handleReportsByUser(res.data.id)
                    // const reportsAvailable = reports.filter(report => reportsUser.find(element => element.report_id === report.id))
                    // setData(reportsAvailable)
                    setData(reportsUser)
                }
            })
    }, [params.group_id])

    return <Component data={data} params={params} user={user} />
}

export default Page