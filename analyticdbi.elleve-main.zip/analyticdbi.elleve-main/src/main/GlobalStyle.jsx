import { createGlobalStyle } from 'styled-components'

const GlobalStyle = createGlobalStyle`
    :root {
        --color-sidebar: #824eee;
        --color-sidebar-hover: #5a32af;
        --color-background: #f8f8f8;
        --color-background-card: #ffffff;
        --color-background-title-bar: #f8f8f8;
        --color-background-footer: #f8f8f8;
        --color-background-input: #eee6fd;
        --color-font: #230b59;
        --color-icons: #FFFFFF;
        --color-white: #FFFFFF;
        --color-grey: #d3cede;
        --color-blue: #824eee;
        --color-green: #2ced89;
        --color-orange: #ffc20e;
        --color-red: #f58229;
        --color-yellow: #ebc212;
    }
    * {
        box-sizing: border-box;
    }
    body {
        font-family: Arial, Helvetica, sans-serif;
        margin: 0;
		padding: 0;
        background-color: var(--color-background);
        color: var(--color-font);
    }
    h1, h2, h3, h4, h5, h6, p {
        margin: 0;
    }
`
export default GlobalStyle